sap.ui.define([
	"demo/sapui5ml/test/unit/controller/demo.controller"
], function () {
	"use strict";
});